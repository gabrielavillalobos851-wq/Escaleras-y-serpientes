const path = require('path');
const http = require('http');
const express = require('express');
const { Server } = require('socket.io');
const { randomInt } = require('crypto');

const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, 'public')));

const rooms = new Map();
const QUESTIONS = [
  ['¿Cuál es el principal mineral de calcio presente en huesos y dientes?',['Hidroxiapatita','Cloruro de calcio','Nitrato de calcio','Sulfato de calcio'],0],
  ['¿Qué proceso geológico libera calcio de las rocas?',['Meteorización','Fotosíntesis','Fermentación','Transpiración'],0],
  ['¿Qué ion representa al calcio en forma disuelta?',['Ca²⁺','Ca⁻','C⁺','CO₂'],0],
  ['¿Qué organismos pueden ayudar a solubilizar minerales de calcio?',['Algunas bacterias y hongos','Solo mamíferos','Solo peces','Solo insectos'],0],
  ['¿Qué puede transportar calcio desde los continentes hacia el océano?',['Los ríos','La luz solar','El viento únicamente','El fuego'],0],
  ['¿Qué ocurre con el calcio cuando los organismos mueren y se descomponen?',['Puede regresar al suelo o al agua','Desaparece completamente','Se transforma en oxígeno','Se convierte en nitrógeno'],0],
  ['¿Cuál es una función importante del calcio en los seres vivos?',['Formación de huesos y dientes','Producción directa de oxígeno','Formación de nitrógeno','Evaporación del agua'],0],
  ['¿Qué proceso incorpora calcio a estructuras de algunos organismos?',['Biomineralización','Combustión','Fotosíntesis','Evaporación'],0],
  ['¿Qué condición favorece la disolución de carbonatos?',['Agua ligeramente ácida','Ambiente completamente seco','Ausencia de agua','Ausencia de CO₂'],0],
  ['¿Cuál de estos compuestos contiene calcio?',['CaCO₃','NaCl','CO₂','NH₃'],0],
  ['¿Qué proceso puede devolver calcio al medio durante la descomposición?',['Mineralización','Combustión nuclear','Fotosíntesis','Condensación'],0],
  ['¿Qué papel tienen los océanos en el ciclo del calcio?',['Son un reservorio y lugar de sedimentación','No participan','Solo producen calcio','Eliminan todo el calcio'],0]
];
const ladders = {4:14,8:20,13:27,21:38,29:44,34:49};
const snakes = {18:7,25:11,32:16,41:23,47:30};
const icons = ['🔵','🔴','🟢','🟣','🟠','🟡'];

function code(){ let c; do c=Math.random().toString(36).slice(2,7).toUpperCase(); while(rooms.has(c)); return c; }
function players(r){ return [...r.players.values()].filter(p=>!p.host); }
function publicRoom(r){
  return {code:r.code,started:r.started,over:r.over,turn:r.turn,
    players:[...r.players.values()].map(p=>({id:p.id,name:p.name,icon:p.icon,pos:p.pos,connected:p.connected,host:p.host})),
    question:r.question?{text:r.question[0],answers:r.question[1]}:null,
    selected:r.selected,canRoll:r.canRoll,winner:r.winner,log:r.log};
}
function emitRoom(r){ io.to(r.code).emit('state', publicRoom(r)); }
function nextQuestion(r){
  let available=QUESTIONS.map((_,i)=>i).filter(i=>!r.used.includes(i));
  if(!available.length){r.used=[];available=QUESTIONS.map((_,i)=>i);}
  const i=available[randomInt(available.length)]; r.used.push(i);
  r.question=QUESTIONS[i]; r.selected=null; r.canRoll=false;
}
function addPlayer(r,socket,name,isHost=false){
  const p={id:socket.id,name:(name|| (isHost?'Coordinador':'Jugador')).trim().slice(0,20),icon:isHost?'🎙️':icons[Math.min(players(r).length,5)],pos:1,host:isHost,connected:true};
  r.players.set(socket.id,p); socket.join(r.code); socket.data.room=r.code; return p;
}
function isHost(r,s){return r.host===s.id;}

io.on('connection', socket=>{
  socket.on('createRoom',name=>{
    const r={code:code(),host:socket.id,started:false,over:false,turn:0,players:new Map(),question:null,selected:null,canRoll:false,winner:null,log:'Sala creada. Comparte el código con los jugadores.',used:[]};
    rooms.set(r.code,r); addPlayer(r,socket,name,true); socket.emit('roomCreated',r.code); emitRoom(r);
  });
  socket.on('joinRoom',({code,name})=>{
    const r=rooms.get(String(code||'').toUpperCase());
    if(!r)return socket.emit('errorMsg','Sala no encontrada.');
    if(r.started)return socket.emit('errorMsg','La partida ya comenzó.');
    if(players(r).length>=6)return socket.emit('errorMsg','Ya hay 6 jugadores en la sala.');
    addPlayer(r,socket,name,false); socket.emit('joined',r.code); emitRoom(r);
  });
  socket.on('startGame',()=>{
    const r=rooms.get(socket.data.room); if(!r||!isHost(r,socket))return;
    if(players(r).length!==6)return socket.emit('errorMsg','Deben entrar los 6 jugadores antes de iniciar.');
    r.started=true;r.over=false;r.turn=0;r.winner=null;r.log='Partida iniciada. Responde la pregunta para poder avanzar.';nextQuestion(r);emitRoom(r);
  });
  socket.on('selectAnswer',i=>{
    const r=rooms.get(socket.data.room); if(!r||!r.started||r.over)return;
    const p=players(r)[r.turn]; if(!p||p.id!==socket.id||!r.question)return;
    r.selected=Number(i); r.log=`${p.name} seleccionó una respuesta. El coordinador debe validarla.`; emitRoom(r);
  });
  socket.on('validate',ok=>{
    const r=rooms.get(socket.data.room); if(!r||!isHost(r,socket)||r.selected===null||!r.question)return;
    const p=players(r)[r.turn];
    if(ok){r.canRoll=true;r.log=`✅ Respuesta de ${p.name} marcada como correcta. Puede lanzarse el dado.`;}
    else{r.log=`❌ Respuesta de ${p.name} marcada como incorrecta. Pierde el turno.`;r.turn=(r.turn+1)%players(r).length;nextQuestion(r);}
    emitRoom(r);
  });
  socket.on('roll',()=>{
    const r=rooms.get(socket.data.room); if(!r||!isHost(r,socket)||!r.canRoll||r.over)return;
    const ps=players(r),p=ps[r.turn],d=randomInt(1,7),old=p.pos; p.pos=Math.min(50,p.pos+d);
    let msg=`🎲 ${p.name} sacó ${d}: ${old} → ${p.pos}.`;
    if(p.pos===50){r.over=true;r.winner=p.name;r.canRoll=false;r.log=msg+' 🏆 ¡Ganó la partida!';return emitRoom(r);}
    if(ladders[p.pos]){p.pos=ladders[p.pos];msg+=` 🪜 Subió hasta ${p.pos}.`;}
    else if(snakes[p.pos]){p.pos=snakes[p.pos];msg+=` 🐍 Bajó hasta ${p.pos}.`;}
    r.log=msg;r.canRoll=false;r.turn=(r.turn+1)%ps.length;nextQuestion(r);emitRoom(r);
  });
  socket.on('reset',()=>{
    const r=rooms.get(socket.data.room); if(!r||!isHost(r,socket))return;
    players(r).forEach(p=>p.pos=1);r.started=false;r.over=false;r.turn=0;r.question=null;r.selected=null;r.canRoll=false;r.winner=null;r.used=[];r.log='Partida reiniciada. Esperando al coordinador.';emitRoom(r);
  });
  socket.on('disconnect',()=>{
    const r=rooms.get(socket.data.room); if(!r)return; const p=r.players.get(socket.id); if(p)p.connected=false;
    if(r.host===socket.id){r.over=true;r.log='⚠️ El coordinador se desconectó. La partida quedó detenida.';} emitRoom(r);
  });
});

const PORT=process.env.PORT||3000;
server.listen(PORT,()=>console.log(`Juego ejecutándose en puerto ${PORT}`));
