# 🐍🪜 Serpientes y Escaleras: Ciclo del Calcio

Proyecto web multijugador para **1 coordinador + exactamente 6 jugadores**, con sincronización en tiempo real mediante Socket.IO.

## Estructura

- `server.js`: servidor, salas, turnos, preguntas, validación, dado, serpientes/escaleras y ganador.
- `public/index.html`: interfaz para celulares y computadoras.
- `package.json`: dependencias y comando de inicio.

## Publicación en Internet

Este proyecto necesita un hosting que ejecute **Node.js** y permita conexiones WebSocket/Socket.IO.

Configuración típica del hosting:

- Runtime: Node.js 20 o superior
- Build/Install: `npm install`
- Start: `npm start`
- Puerto: el servidor usa automáticamente `process.env.PORT`

Después de publicar, el hosting entregará una dirección `https://...`. Esa es la dirección que puedes enviar a los participantes.

## Uso

1. El coordinador abre la dirección web y pulsa **Crear sala como coordinador**.
2. Copia el código de 5 caracteres y lo comparte.
3. Los 6 jugadores abren la misma dirección, escriben su nombre y el código.
4. El coordinador inicia la partida cuando están los 6.
5. El jugador de turno responde desde su celular.
6. El coordinador pulsa **Correcta** o **Incorrecta**.
7. Si es correcta, el coordinador lanza el dado.
8. Todos ven simultáneamente el movimiento, las serpientes, las escaleras y el turno siguiente.
9. Gana quien llegue a la casilla 50.

## Importante

Las salas viven en la memoria del servidor. Si el servidor se reinicia, las partidas activas se pierden. No se necesitan cuentas ni contraseñas para jugar.
